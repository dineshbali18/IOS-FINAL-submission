import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var emailIDOL: UITextField!
    @IBOutlet weak var passwordOL: UITextField!
    @IBOutlet weak var LoginButtonOL: UIButton!
    @IBOutlet weak var SignUpButtonOL: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func LoginButton(_ sender: Any) {
        guard let email = emailIDOL.text, !email.isEmpty,
              let password = passwordOL.text, !password.isEmpty else {
            showAlert(message: "Please fill in all fields.")
            return
        }

        let signInData: [String: Any] = [
            "email": email,
            "password": password
        ]

        sendSignInRequest(data: signInData)
    }

    func sendSignInRequest(data: [String: Any]) {
        guard let url = URL(string: "http://52.15.151.130:8888/v1/user/login") else {
            showAlert(message: "Invalid URL.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: data, options: [])
            if let requestBody = String(data: request.httpBody!, encoding: .utf8) {
                print("Request Body: \(requestBody)")
            }
        } catch {
            showAlert(message: "Error serializing data: \(error.localizedDescription)")
            return
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(message: "Network error: \(error.localizedDescription)")
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    self.showAlert(message: "Invalid response from server.")
                }
                return
            }

            print("HTTP Status Code: \(httpResponse.statusCode)")

            if httpResponse.statusCode != 200 {
                DispatchQueue.main.async {
                    self.showAlert(message: "Invalid login credentials.")
                }
                return
            }

            if let data = data, let responseDict = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
               let token = responseDict["token"] as? String,
               let refreshToken = responseDict["refreshToken"] as? String,
               let name = responseDict["name"] as? String,
               let role = responseDict["role"] as? String {
                // Store in UserDefaults
                UserDefaults.standard.set(token, forKey: "authToken")
                UserDefaults.standard.set(refreshToken, forKey: "refreshToken")
                UserDefaults.standard.set(name, forKey: "userName")
                UserDefaults.standard.set(role, forKey: "userRole")

                print("Server Response: \(responseDict)")

                // Navigate to the next screen
                DispatchQueue.main.async {
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    if let hotelVC = storyboard.instantiateViewController(withIdentifier: "HotelViewController") as? HotelViewController {
                        self.navigationController?.pushViewController(hotelVC, animated: true)
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self.showAlert(message: "Invalid response format.")
                }
            }
        }

        task.resume()
    }

    @IBAction func SignUPButton(_ sender: Any) {
        // Handle sign-up button action if needed
    }

    func showAlert(message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: "QuickBite", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            completion?()
        }))
        present(alert, animated: true)
    }
}
