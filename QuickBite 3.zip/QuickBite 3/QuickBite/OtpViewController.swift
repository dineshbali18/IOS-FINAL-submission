//
//  OtpViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

class OtpViewController: UIViewController {

    @IBOutlet weak var MailOL: UILabel!
    
    @IBOutlet weak var OtpOL: UITextField!

    @IBOutlet weak var VerifyButtonOL: UIButton!
   
    @IBOutlet weak var IncorrectOtpOL: UILabel!
    
    @IBOutlet weak var CancelButtonOL: UIButton!
    
    @IBOutlet weak var ResetButtonOL: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func VerifyButton(_ sender: Any) {
    }
    
    
    @IBAction func CancelButton(_ sender: Any) {
    }
    
    
    @IBAction func ResetButton(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
