//
//  CartCollectionViewCell.swift
//  QuickBite
//
//  Created by Dinesh Bali on 12/9/24.
//

import UIKit

class CartCollectionViewCell: UICollectionViewCell {
    

    @IBOutlet weak var imageOL: UIImageView!
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    
    @IBOutlet weak var priceOL: UILabel!
    
    func assignItem(with cart: Cart) {
        
        print("CART:::\(cart.name)")
        

    }



        override func awakeFromNib() {
            super.awakeFromNib()
            self.backgroundColor = .gray // Or .clear, depending on your design
            print("Cell loaded")
        }

  

    }


