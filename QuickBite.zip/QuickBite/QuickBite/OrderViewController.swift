//
//  OrderViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

class OrderViewController: UIViewController {

    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var EstimatedTimeOL: UILabel!
    
    @IBOutlet weak var AdressOL: UITextField!
    
    @IBOutlet weak var CountryNumOL: UITextField!
    
    @IBOutlet weak var TotalCostOL: UILabel!
    
    @IBOutlet weak var PhoneNumOL: UITextField!
    
    @IBOutlet weak var PlaceOrderButtonOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func PlaceOrderButton(_ sender: Any) {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
