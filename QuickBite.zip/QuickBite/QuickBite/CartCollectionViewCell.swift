import UIKit

class CartCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageOL: UIImageView!
    @IBOutlet weak var nameOL: UILabel!
    @IBOutlet weak var costOL: UILabel!
    @IBOutlet weak var incrementOL: UIButton!
    @IBOutlet weak var decrementOL: UIButton!
    @IBOutlet weak var quantityOL: UILabel!
    
//    var cartItem: Cart? // To hold the cart item data

    func assignItem(with cart: Cart) {
        // Assign values to UI elements from the Cart object
        print("AAAAAAA\(cart.name!)")
        nameOL.text = "Name: \(cart.name!)"
        costOL.text = "Price: \(cart.price!)"
//        quantityOL.text = "Quantity: 1"  // Default quantity if not set elsewhere
        
        // Optionally, you can set an image if you have a URL or local asset for `imageOL`
//        if let imageName = cart. {
//            imageOL.image = UIImage(named: imageName) // Assuming `cart.image` contains the name of a local image
//        }
        
//        cartItem = cart 
    }
    
    @IBAction func incrementButton(_ sender: Any) {
        // Increment the quantity and update the UI accordingly
        if var currentQuantity = Int(quantityOL.text?.components(separatedBy: " ").last ?? "1") {
            currentQuantity += 1
            quantityOL.text = "Quantity: \(currentQuantity)"
        }
    }
    
    @IBAction func decrementButton(_ sender: Any) {
        // Decrement the quantity, ensuring it doesn't go below 1
        if var currentQuantity = Int(quantityOL.text?.components(separatedBy: " ").last ?? "1"), currentQuantity > 1 {
            currentQuantity -= 1
            quantityOL.text = "Quantity: \(currentQuantity)"
        }
    }
}
