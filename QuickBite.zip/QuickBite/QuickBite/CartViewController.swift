//
//  CartViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 12/9/24.
//

import UIKit
struct UserCart: Decodable {
    var products: [Cart]
    
    init(products: [Cart]) {
        self.products = products
    }
    
    enum CodingKeys: String, CodingKey {
        case products
    }
}

struct Cart: Decodable {
    var name: String?
    var price: Int?
   
    
    init(name: String? = nil, price: Int? = nil) {
        self.name = name
        self.price = price
    }

    // Map JSON keys to your struct properties
    enum CodingKeys: String, CodingKey {
        case name = "name"
        case price = "price"
    }
}
class CartViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    
    @IBOutlet weak var cartCollectionViewCell: UICollectionView!
    
    var userCart :UserCart = UserCart(products: [])
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return userCart.products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cartCell", for: indexPath) as! CartCollectionViewCell
        print("Passing data to cell \(userCart.products[indexPath.row])")
        cell.assignItem(with: userCart.products[indexPath.row])
            
        return cell
    }
    

    @IBOutlet weak var cartCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//        let nib = UINib(nibName: "CartCollectionViewCell", bundle: nil)
//        cartCollectionView.register(nib, forCellWithReuseIdentifier: "cartCell")

        cartCollectionView.register(CartCollectionViewCell.self, forCellWithReuseIdentifier: "cartCell")

        
        let layout = UICollectionViewFlowLayout()
        // Do any additional setup after loading the view.
//        if let layout = cartCollectionView.collectionViewLayout as? UICollectionViewFlowLayout {
//            layout.itemSize = CGSize(width: 150, height: 150) // Adjust as needed
//            layout.minimumInteritemSpacing = 10
//            layout.minimumLineSpacing = 10
//        }
        cartCollectionView.delegate = self
        cartCollectionView.dataSource = self
        fetchUserCart()
        

    }
    
    func fetchUserCart() {
        
        print("FETCHING CART......")
            guard let url = URL(string: "http://52.15.151.130:8888/v1/user/cart?userID=1") else {
                print("Invalid URL")
                return
            }

            let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
                if let error = error {
                    print("Error fetching cart: \(error)")
                    return
                }

                guard let data = data else {
                    print("No data received")
                    return
                }

                do {
                    // Decode JSON into UserCart structure
                    let decoder = JSONDecoder()
                    self!.userCart = try decoder.decode(UserCart.self, from: data)
                    
                    
                    // Log product names for debugging
                    print("Fetched products:\(self!.userCart)")
                    
                    
//                    self!.cart = self!.userCart.products
//                    self?.cart.forEach { print($0.name ?? "Unknown Product") }

                    // Reload the collection view on the main thread
                    DispatchQueue.main.async {
                        self?.cartCollectionView.reloadData()
                    }
                } catch {
                    print("Failed to decode JSON: \(error)")
                }
            }

            task.resume()
        }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
