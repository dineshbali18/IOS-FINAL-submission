import UIKit

struct UserCart: Decodable {
    var products: [Cart]
    
    init(products: [Cart]) {
        self.products = products
    }
    
    enum CodingKeys: String, CodingKey {
        case products
    }
}

struct Cart: Decodable {
    var id: Int?
    var name: String?
    var stockLeft: Int?
    var hotelID: Int?
    var category: String?
    var price: Int?
    var hotelName: String?
    
    init(id: Int? = nil, name: String? = nil, stockLeft: Int? = nil, hotelID: Int? = nil, category: String? = nil, price: Int? = nil, hotelName: String? = nil) {
        self.id = id
        self.name = name
        self.stockLeft = stockLeft
        self.hotelID = hotelID
        self.category = category
        self.price = price
        self.hotelName = hotelName
    }

    // Map JSON keys to your struct properties
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case stockLeft
        case hotelID = "hotel_id"
        case category
        case price
        case hotelName = "hotel_name"
    }
}

class CartViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
//    var userCart: UserCart
    var userCart = UserCart(products: [])
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("user cart length:::\(userCart.products.count)")
        return userCart.products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cartCell", for: indexPath) as! CartCollectionViewCell
        cell.assignItem(with: userCart.products[indexPath.row])
    
        return cell
    }

    
    @IBOutlet weak var cartCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let layout = UICollectionViewFlowLayout()

//        let layout = UICollectionViewFlowLayout()
//        let layout = UICollectionViewFlowLayout()
//        layout.scrollDirection = .vertical
//        layout.itemSize = CGSize(width: 100, height: 150) // Adjust as needed
//        layout.minimumLineSpacing = 10
//        layout.minimumInteritemSpacing = 10
//        cartCollectionView.collectionViewLayout = layout

        cartCollectionView.delegate = self
        cartCollectionView.dataSource = self
        
        fetchUserCart()
    }
    

    
    func fetchUserCart() {
        guard let url = URL(string: "http://52.15.151.130:8888/v1/user/cart?userID=1") else {
            print("Invalid URL")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                print("Error fetching cart: \(error)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                // Decode JSON into UserCart structure
                let decoder = JSONDecoder()
                let userCartResponse = try decoder.decode(UserCart.self, from: data)
                
                // Update cart array
               // self?.userCart = userCartResponse
                
                // Log product names for debugging
                print("Fetched products:\(self?.userCart)")
//                self?.cart.forEach { print($0.name ?? "Unknown Product") }

                // Reload the collection view on the main thread
                DispatchQueue.main.async {
                    self?.cartCollectionView.reloadData()
                }
            } catch {
                print("Failed to decode JSON: \(error)")
            }
        }

        task.resume()
    }
}
