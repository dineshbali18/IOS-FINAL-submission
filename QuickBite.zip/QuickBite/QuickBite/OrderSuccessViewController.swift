//
//  OrderSuccessViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

class OrderSuccessViewController: UIViewController {

    @IBOutlet weak var OrderPlacedimage: UIImageView!
    
    @IBOutlet weak var BackToHomePageButtonOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func BackToHomePageButton(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
