//
//  GotocartViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

struct Product: Decodable {
    var id:Int?
    var name: String?
    var price: Int?
    var category: String?
    var image: String?
    init(id: Int? = nil, name: String? = nil, price: Int? = nil, category: String? = nil, image: String? = nil) {
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.image = image
    }

    // Map JSON keys to your struct properties if they differ
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case name = "name" // Maps JSON key "name" to "hotelName"
        case price = "price"
        case category = "category"
        case image = "image"
    }
}

class GotocartViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var products : [Product] = []
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "productCell", for: indexPath) as! MenuCollectionViewCell
        cell.assignItem(with: products[indexPath.row])
        return cell
    }
    

    @IBOutlet weak var GoTOCartButtonOL: UIButton!
    
    
    @IBOutlet weak var MenuCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
      
            
            // Assuming collectionView is already connected via an IBOutlet
            let layout = UICollectionViewFlowLayout()
            layout.scrollDirection = .vertical // Vertically scrollable
            layout.minimumLineSpacing = 10     // Spacing between rows
            layout.minimumInteritemSpacing = 10 // Spacing between columns

            let width = (view.frame.size.width - 30) / 2 // Divide the screen width into 2, considering spacing
            layout.itemSize = CGSize(width: width, height: 200) // Adjust the height as needed
            
            MenuCollectionView.collectionViewLayout = layout
        
        MenuCollectionView.delegate = self;
        MenuCollectionView.dataSource = self;
        
        fetchProducts()
    }
    
    
    func fetchProducts(){
        
        // modify hotel_id basing on which hotel the user has clicked.
        guard let url = URL(string: "http://52.15.151.130:8888/v1/hotel/1/products") else {
                    print("Invalid URL")
                    return
                }
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
                    if let error = error {
                        print("Error fetching hotels: \(error)")
                        return
                    }

                    guard let data = data else {
                        print("No data received")
                        return
                    }
            
            print("DDDAAATTTAAA:::\(data)")

                    do {
                        // Decode JSON response into an array of Hotel
                        let decoder = JSONDecoder()
                        self!.products = try decoder.decode([Product].self, from: data)
                        
//                        print("DDDAAATTTAAA11:::\(String(describing: self!.products[0].price))")
                        
                        // to reinvoke the collection view methods.
                        
                        DispatchQueue.main.async {
                            self?.MenuCollectionView.reloadData()
                                    }
                        
                    } catch {
                        print("Failed to decode JSON: \(error)")
                    }
                }

                task.resume()
    }
    
    func showAlert(from cell: MenuCollectionViewCell,message:String) {
            // Show an alert
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    
    
    
    
    @IBAction func GoTOCartButton(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
