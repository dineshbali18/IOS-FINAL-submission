//
//  HotelViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit
import Vision

//struct Hotel{
//    var hotelName:String?
//    var city: String?
//    var image: String?
//    var rating:String?
//    init(hotelName: String? = nil, city: String? = nil, rating: String? = nil) {
//        self.hotelName = hotelName
//        self.city = city
//        self.rating = rating
//    }
//}

struct Hotel: Decodable {
    var hotelName: String?
    var city: String?
    var image: String?
    var rating: String?
    init(hotelName: String? = nil, city: String? = nil, rating: String? = nil) {
        self.hotelName = hotelName
        self.city = city
        self.rating = rating
    }

    // Map JSON keys to your struct properties if they differ
    enum CodingKeys: String, CodingKey {
        case hotelName = "name" // Maps JSON key "name" to "hotelName"
        case city = "city"
        case image = "image"
        case rating = "state"
    }
}


class HotelViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate {
    
    var hotels : [Hotel] = []
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return hotels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "hotelCell", for: indexPath) as! HotelCollectionViewCell
        print("passing data to hotel \(hotels[indexPath.row])")
       cell.assignItem(with: hotels[indexPath.row])
        return cell
    }
    

    @IBOutlet weak var UserNameLabelOL: UILabel!
    
    @IBOutlet weak var SearchOL: UISearchBar!
    
    
    @IBOutlet weak var cameraBtn: UIButton!
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    @IBOutlet weak var HotelCollectionView: UICollectionView!
    
    
    
//
//    // hotel related info
//    
    @IBOutlet weak var hotelName: UILabel!
    @IBOutlet weak var hotelImage: UIImageView!
    
    @IBOutlet weak var hotelNameOL: UILabel!
    
    @IBOutlet weak var hotelRating: UILabel!
    
    @IBOutlet weak var hotelCity: UILabel!
//    
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if let value = UserDefaults.standard.string(forKey: "userName") {
            print("Value from cache: \(value)")
            UserNameLabelOL.text  = value + "👋"
        } else {
            print("No value found in cache")
            UserNameLabelOL.text = "user"
        }
        
        //camera
        imagePicker.delegate = self
        imagePicker.sourceType = .camera
        
        
        HotelCollectionView.delegate = self
        HotelCollectionView.dataSource = self
        
        fetchHotels()
        
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let userImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imageViewOL.image =  userImage
        }
        
        imagePicker.dismiss(animated: true,completion: nil)
    }
    
    
    @IBAction func onCameraBtnClicked(_ sender: Any) {
        present(imagePicker,animated: true, completion: nil)
    }
    
    
    func fetchHotels(){
//        http://52.15.151.130:8888/v1/hotel
        
        guard let url = URL(string: "http://52.15.151.130:8888/v1/hotel") else {
                    print("Invalid URL")
                    return
                }
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
                    if let error = error {
                        print("Error fetching hotels: \(error)")
                        return
                    }

                    guard let data = data else {
                        print("No data received")
                        return
                    }
            
            print("DDDAAATTTAAA:::\(data)")

                    do {
                        // Decode JSON response into an array of Hotel
                        let decoder = JSONDecoder()
                        self!.hotels = try decoder.decode([Hotel].self, from: data)
                        
                        print("DDDAAATTTAAA11:::\(self!.hotels[0].city)")
                        
                        // to reinvoke the collection view methods.
                        
                        DispatchQueue.main.async {
                                        self?.HotelCollectionView.reloadData()
                                    }
                        
                    } catch {
                        print("Failed to decode JSON: \(error)")
                    }
                }

                task.resume()
            }
    

//func updateUI(with hotels: [Hotel]) {
//    guard let firstHotel = hotels.first else { return }

    // Update hotel information UI with the first hotel in the list
//    hotelNameOL.text = firstHotel.hotelName
//    hotelCity.text = firstHotel.city
//    hotelRating.text = "Rating: \(firstHotel.rating ?? "N/A")"
    //hotelImage.text = firstHotel.image
//    if let imageUrlString = firstHotel.image, let imageUrl = URL(string: imageUrlString) {
//        // Load image asynchronously
//        loadImage(from: imageUrl) { [weak self] image in
//            DispatchQueue.main.async {
//                self?.hotelImage.image = image
//            }
//        }
//    }
//}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
