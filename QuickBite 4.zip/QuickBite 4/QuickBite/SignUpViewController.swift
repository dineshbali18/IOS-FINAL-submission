//
//  SignUpViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

class SignUpViewController: UIViewController {
    
    
    @IBOutlet weak var NameOL: UITextField!
    
    @IBOutlet weak var EmailOL: UITextField!
    
    @IBOutlet weak var NumberOL: UITextField!
    
    @IBOutlet weak var EnterPsswordOL: UITextField!
    
    @IBOutlet weak var ConfirmPasswordOL: UITextField!
    
    @IBOutlet weak var SignUpButtonOL: UIButton!
    
    override func viewDidLoad() {
          super.viewDidLoad()
          // Do any additional setup after loading the view.
      }

      @IBAction func SignUpButton(_ sender: Any) {
          // Validate inputs
          guard let name = NameOL.text, !name.isEmpty,
                let email = EmailOL.text, !email.isEmpty,
                let numberString = NumberOL.text, !numberString.isEmpty,
                let number = Int(numberString),
                let password = EnterPsswordOL.text, !password.isEmpty,
                let confirmPassword = ConfirmPasswordOL.text, !confirmPassword.isEmpty else {
              showAlert(message: "Please fill in all fields.")
              return
          }
          
          // Check if passwords match
          guard password == confirmPassword else {
              showAlert(message: "Passwords do not match.")
              return
          }
          
          // Prepare the data to be sent
          let signUpData: [String: Any] = [
              "name": name,
              "email": email,
              "phone_number": number,
              "password_hash": password,
              "role": "user"
          ]
          
          // Call the sign-up API
          sendSignUpRequest(data: signUpData)
      }

    func sendSignUpRequest(data: [String: Any]) {
        // Define the API URL
        guard let url = URL(string: "http://52.15.151.130:8888/v1/create/user") else {
            showAlert(message: "Invalid URL.")
            return
        }

        // Create the URLRequest
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // Log the request endpoint
        print("Request Endpoint: \(url)")

        // Convert data to JSON
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: data, options: [])
            
            // Log the request body
            if let requestBody = String(data: request.httpBody!, encoding: .utf8) {
                print("Request Body: \(requestBody)")
            }
        } catch {
            showAlert(message: "Error serializing data: \(error.localizedDescription)")
            return
        }

        // Create the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle network errors
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(message: "Network error: \(error.localizedDescription)")
                }
                return
            }

            // Validate response
            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    self.showAlert(message: "Invalid response from server.")
                }
                return
            }

            // Handle non-201 status codes (assuming 201 is the success code)
            if httpResponse.statusCode != 201 {
                DispatchQueue.main.async {
                    self.showAlert(message: "Server returned status code: \(httpResponse.statusCode)")
                }
                return
            }

            // Handle successful response with plain string
            if let data = data, let responseString = String(data: data, encoding: .utf8) {
                DispatchQueue.main.async {
                    print("Server Response: \(responseString)")
                    self.showAlert(message: responseString)
                }
            } else {
                DispatchQueue.main.async {
                    self.showAlert(message: "Unable to decode response from server.")
                }
            }
        }

        // Start the task
        task.resume()
    }


      func showAlert(message: String) {
          let alert = UIAlertController(title: "QuickBite", message: message, preferredStyle: .alert)
          alert.addAction(UIAlertAction(title: "OK", style: .default))
          present(alert, animated: true)
      }
  }
