//
//  Hotels.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import Foundation
