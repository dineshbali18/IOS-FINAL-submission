//
//  MenuCollectionViewCell.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

protocol MenuCollectionViewCellDelegate: AnyObject {
    func showAlert(from cell: MenuCollectionViewCell,message:String)
}

class MenuCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image1OL: UIImageView!
    
    @IBOutlet weak var name1OL: UILabel!
    
    
    @IBOutlet weak var rate1OL: UILabel!
    
    
    @IBOutlet weak var increment1OL: UIButton!
    
    weak var delegate: GotocartViewController?
    
//    @IBAction func showAlertButtonTapped(_ sender: UIButton) {
//        delegate?.showAlert(from: self,message: "")
//        }
    
    var productID:Int = 0
    
    
    func assignItem(with product : Product){
        name1OL.text = product.name
        rate1OL.text = "Price : \(product.price!)"
        image1OL.image = UIImage(named: product.image!)
        productID = product.id!
    }

    
    @IBAction func incrementBtn(_ sender: Any) {
        // quantity should be basing on the product
        print("product-id:\(productID)")
        let authToken = UserDefaults.standard.string(forKey: "authToken")
        print("TOKEN:::\(String(describing: authToken))")
        //        let userID = UserDefaults.standard.string(forKey: "userID")
        
        let userID = 1
        let addProductToCartData: [String: Any] = [
            "product_id": productID,
            "user_id": 1,
            "quantity": 1
        ]
        addProductToCart(data : addProductToCartData)
    }
    
    
    
    func addProductToCart(data: [String: Any]){
        
        guard let url = URL(string: "http://52.15.151.130:8888/v1/add/user/cart") else {
//            self.showAlert(message: "Invalid URL.")
            return
        }
        
        // Create the URLRequest
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Log the request endpoint
        print("Request Endpoint: \(url)")
        
        // Convert data to JSON
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: data, options: [])
            
            // Log the request body
            if let requestBody = String(data: request.httpBody!, encoding: .utf8) {
                print("Request Body: \(requestBody)")
            }
        } catch {
//            self.showAlert(message: "Error serializing data: \(error.localizedDescription)")
            return
        }
        // Create the URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle network errors
            if let error = error {
                DispatchQueue.main.async {
//                    self.showAlert(message: "Network error: \(error.localizedDescription)")
                }
                return
            }
            
            // Validate response
            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
//                    self.showAlert(message: "Invalid response from server.")
                }
                return
            }
            
            // Handle non-201 status codes (assuming 201 is the success code)
            if httpResponse.statusCode != 200 {
                DispatchQueue.main.async {
                    
//                    self.showAlert(message: "Server returned status code: \(httpResponse.statusCode)")
                }
                return
            }
            
            // Handle successful response with plain string
            if let data = data, let responseString = String(data: data, encoding: .utf8) {
                DispatchQueue.main.async {
                    print("Server Response: \(responseString)")
//                    self.showAlert(message: responseString)
                    self.delegate?.showAlert(from: self,message: responseString)
                }
            } else {
                DispatchQueue.main.async {
                    self.delegate?.showAlert(from: self,message: "Unable to decode response from server.")
                }
            }
        }
        
        // Start the task
        task.resume()
    }
    
    

    
    
}
  

    
