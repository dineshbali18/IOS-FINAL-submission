//
//  ItemInfoViewController.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

class ItemInfoViewController: UIViewController {

    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var ItemNameOL: UILabel!
 
    @IBOutlet weak var ItemDescriptionOL: UILabel!
    
    @IBOutlet weak var MostLikedOL: UILabel!
    @IBOutlet weak var RatingOL: UILabel!
    
    @IBOutlet weak var AddToCartOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
//        fetchProductByID(productID: Int)
    }
    
    @IBAction func AddToCartButton(_ sender: Any) {
    }
    
    

}

