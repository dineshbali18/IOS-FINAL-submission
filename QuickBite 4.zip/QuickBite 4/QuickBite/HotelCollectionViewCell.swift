//
//  HotelCollectionViewCell.swift
//  QuickBite
//
//  Created by Dinesh Bali on 11/19/24.
//

import UIKit

class HotelCollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var HotelImageOL: UIImageView!
    
    @IBOutlet weak var HotelNameOL: UILabel!
//    city
    @IBOutlet weak var HotelMileOL: UILabel!
    
    @IBOutlet weak var HotelRatingOL: UILabel!
    

    func assignItem(with hotel: Hotel) {
        print("AAAAAA\(hotel)")
        HotelNameOL.text = hotel.hotelName
        HotelMileOL.text = hotel.city
        HotelRatingOL.text = hotel.rating
        HotelImageOL.image = UIImage(named: hotel.image!)
        
//        let image1 = "http://\(hotel.image)"
//
//        // Load image from URL
//        if let urlString = image1.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
//           let imageUrl = URL(string: urlString) {
//            URLSession.shared.dataTask(with: imageUrl) { data, response, error in
//                if let error = error {
//                    print("Failed to load image: \(error)")
//                    return
//                }
//                guard let data = data, let image = UIImage(data: data) else {
//                    print("Failed to decode image data")
//                    return
//                }
//                DispatchQueue.main.async {
//                    self.HotelImageOL.image = image
//                }
//            }.resume()
//        }

    }
}
